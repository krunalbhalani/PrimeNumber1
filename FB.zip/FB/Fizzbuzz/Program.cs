﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fizzbuzz
{
    class Program
    {
        static void Main(string[] args)
        {
            //Do fizzbuzz activity for 3
            string Fizzbuzzresult1 = Common.fizzbuzz(3);
            Console.WriteLine(Fizzbuzzresult1);
            
            Console.WriteLine("----------------------------------------");
            
            //Do fizzbuzz activity for 5
            string Fizzbuzzresult2 = Common.fizzbuzz(5);
            Console.WriteLine(Fizzbuzzresult2);
            

            Console.WriteLine("----------------------------------------");

             //Do fizzbuzz activity for 15
            string Fizzbuzzresult3 = Common.fizzbuzz(15);
            Console.WriteLine(Fizzbuzzresult3);
            


            Console.WriteLine("----------------------------------------");

            //Do fizzbuzz activity for 4
            string Fizzbuzzresult4 = Common.fizzbuzz(4);
            Console.WriteLine(Fizzbuzzresult4);

            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");

            Console.WriteLine("----------------------------------------");
            Console.WriteLine("Fizzbuzz from 1 to Number Parameter");
            Console.WriteLine("----------------------------------------");
            

            Common.fizzbuzzloop(100);

            Console.WriteLine("---------------------------------------");

            Console.ReadKey();

            
        }
    }
}
