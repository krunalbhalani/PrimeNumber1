﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fizzbuzz
{
    class Common
    {
        //Fizzbuzz of one number
        public static string fizzbuzz(int number)
        {
            
            if (number % 3 == 0 && number % 5 == 0)
            {
                return "Fizzbuzz";
            }
            else if (number % 3 == 0)
            {
                return "Fizz";
            }
            else if (number % 5 == 0)
            {
                return "Buzz";
            }
            else
            {
                return number.ToString();
            }
            
        }

        //Fizzbuzz upto Number
        public static void fizzbuzzloop(int number)
        {

            for (int i = 1; i <= number; i++)
            {

                if (i % 3 == 0 && i % 5 == 0)
                {
                    Console.WriteLine("Fizzbuzz");
                }
                else if (i % 3 == 0)
                {
                    Console.WriteLine("Fizz");
                }
                else if (i % 5 == 0)
                {
                    Console.WriteLine("Buzz");
                }
                else
                {
                    Console.WriteLine(i);
                }
            }

        }

    }
}
